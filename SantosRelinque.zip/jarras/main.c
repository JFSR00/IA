/*
 * main.c
 *
 *  Created on: 7 oct. 2020
 *      Author: Juan Francisco
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "jarras.h"

int main(){
	//pruebas del c�digo generado
	int op;
	tEstado *n,*a;
	a=estadoInicial();

	for(op=1; op<=NUM_OPERADORES; op++){
		dispOperador(op);
		if(esValido(op, a)){
			n=aplicaOperador(op,a);
			dispEstado(n);
		}else{
			printf("\n Operador no v�lido\n");
		}
	}
}
